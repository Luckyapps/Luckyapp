if(document.getElementById("logo") != null){
document.getElementById("logo").children[0].src = "https://www.google.de/images/branding/googlelogo/2x/googlelogo_color_92x30dp.png";
}

if(window.location.origin == "https://de.wikipedia.org"){
//for(i=0; i<document.getElementsByTagName("a").length; i++){/*document.getElementsByTagName("a")[i].style.color = "#00adad";*/document.getElementsByTagName("a")[i].setAttribute('style', 'color:#00adad !important') };
// Create our stylesheet
var style = document.createElement('style');
style.innerHTML =
	':not(a *) {' +
		'color: #9f9f9f !important;' +
		'background-color: black !important;' +
	'}' +
        'a{color:#00adad !important;}' +
        '#p-logo a {background-color: #6f6f6f !important}';

// Get the first script tag
var ref = document.querySelector('script');

// Insert our new styles before the first script tag
ref.parentNode.insertBefore(style, ref);
}

if(window.location.origin == "https://www.wikipedia.de"){
// Create our stylesheet
var style = document.createElement('style');
style.innerHTML 
	':not(a *) {' +
		'color: #9f9f9f !important;' +
		'background-color: black !important;' +
	'}a{color:#00adad !important;}';

// Get the first script tag
var ref = document.querySelector('script');

// Insert our new styles before the first script tag
ref.parentNode.insertBefore(style, ref);
}

if(document.getElementsByClassName("lnXdpd") != null){
document.getElementsByClassName("lnXdpd")[0].src = "https://www.google.de/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png";
document.getElementsByClassName("lnXdpd")[0].srcset = "https://www.google.de/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png 1x, /images/branding/googlelogo/2x/googlelogo_color_272x92dp.png 2x";
}

/*if(window.location == "chrome://new-tab-page/"){
//document.getElementsByTagName("ntp-app")[0].$.logo.shadowRoot.styleSheets[1].rules[3].cssText = ':host([single-colored]) #logo { -webkit-mask-image: url("chrome://new-tab-page/icons/google_logo.svg"); -webkit-mask-repeat: no-repeat; -webkit-mask-size: 100%; background-image: url("chrome://new-tab-page/icons/google_logo.svg");}';
//document.getElementById("logo").style.BackgroundImage = "url('chrome://new-tab-page/icons/google_logo.svg')";
document.getElementsByTagName("ntp-app")[0].$.logo.shadowRoot.styleSheets[1].rules[3].cssText = ':host([single-colored]) #logo {background-image: url("chrome://new-tab-page/icons/google_logo.svg");}';
}*/


